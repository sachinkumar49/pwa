import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-career-overview',
  templateUrl: './career-overview.component.html',
  styleUrls: ['./career-overview.component.scss']
})
export class CareerOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
