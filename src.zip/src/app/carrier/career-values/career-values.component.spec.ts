import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CareerValuesComponent } from './career-values.component';

describe('CareerValuesComponent', () => {
  let component: CareerValuesComponent;
  let fixture: ComponentFixture<CareerValuesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CareerValuesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CareerValuesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
