import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-career-values',
  templateUrl: './career-values.component.html',
  styleUrls: ['./career-values.component.scss']
})
export class CareerValuesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
