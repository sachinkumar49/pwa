import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CurrentOpenPostionComponent } from './current-open-postion.component';

describe('CurrentOpenPostionComponent', () => {
  let component: CurrentOpenPostionComponent;
  let fixture: ComponentFixture<CurrentOpenPostionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CurrentOpenPostionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CurrentOpenPostionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
