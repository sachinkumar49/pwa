import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-current-open-postion',
  templateUrl: './current-open-postion.component.html',
  styleUrls: ['./current-open-postion.component.scss']
})
export class CurrentOpenPostionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
