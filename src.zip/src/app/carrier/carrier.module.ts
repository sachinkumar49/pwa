import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CareerOverviewComponent } from './career-overview/career-overview.component';
import { CareerValuesComponent } from './career-values/career-values.component';
import { CurrentOpenPostionComponent } from './current-open-postion/current-open-postion.component';
import { RouterModule } from '@angular/router';
const router = [
  {path: 'careerOverview', component: CareerOverviewComponent},
  {path: 'careerValues', component: CareerValuesComponent},
  {path: 'currentOpenPostion', component: CurrentOpenPostionComponent}
];
@NgModule({
  declarations: [CareerOverviewComponent, CareerValuesComponent, CurrentOpenPostionComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(router),
  ]
})
export class CarrierModule { }
