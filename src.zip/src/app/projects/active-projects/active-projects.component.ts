import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-active-projects',
  templateUrl: './active-projects.component.html',
  styleUrls: ['./active-projects.component.scss']
})
export class ActiveProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
