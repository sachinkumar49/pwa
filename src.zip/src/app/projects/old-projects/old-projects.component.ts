import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-old-projects',
  templateUrl: './old-projects.component.html',
  styleUrls: ['./old-projects.component.scss']
})
export class OldProjectsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
