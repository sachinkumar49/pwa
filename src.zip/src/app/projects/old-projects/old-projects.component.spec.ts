import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OldProjectsComponent } from './old-projects.component';

describe('OldProjectsComponent', () => {
  let component: OldProjectsComponent;
  let fixture: ComponentFixture<OldProjectsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OldProjectsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OldProjectsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
