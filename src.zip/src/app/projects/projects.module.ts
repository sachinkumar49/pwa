import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActiveProjectsComponent } from './active-projects/active-projects.component';
import { OldProjectsComponent } from './old-projects/old-projects.component';
import { RouterModule } from '@angular/router';
const router = [
  {path: 'activeProjects', component: ActiveProjectsComponent},
  {path: 'completedProject', component: OldProjectsComponent},
];
@NgModule({
  declarations: [ActiveProjectsComponent, OldProjectsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(router),
  ]
})
export class ProjectsModule { }
