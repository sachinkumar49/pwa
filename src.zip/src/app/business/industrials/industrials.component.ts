import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-industrials',
  templateUrl: './industrials.component.html',
  styleUrls: ['./industrials.component.scss']
})
export class IndustrialsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
