import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-railways',
  templateUrl: './railways.component.html',
  styleUrls: ['./railways.component.scss']
})
export class RailwaysComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
