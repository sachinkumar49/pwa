import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-highways',
  templateUrl: './highways.component.html',
  styleUrls: ['./highways.component.scss']
})
export class HighwaysComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
