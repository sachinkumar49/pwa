import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HighwaysComponent } from './highways/highways.component';
import { RailwaysComponent } from './railways/railways.component';
import { BridgesComponent } from './bridges/bridges.component';
import { IndustrialsComponent } from './industrials/industrials.component';
import { RouterModule } from '@angular/router';
const router = [
  {path: 'RoadsAndHighways', component: HighwaysComponent},
  {path: 'railways', component: RailwaysComponent},
  {path: 'bridges', component: BridgesComponent},
  {path: 'landDevelopment', component: IndustrialsComponent}
];
@NgModule({
  declarations: [HighwaysComponent, RailwaysComponent, BridgesComponent, IndustrialsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(router),
  ]
})
export class BusinessModule { }
