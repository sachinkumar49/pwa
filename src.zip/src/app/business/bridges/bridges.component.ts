import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bridges',
  templateUrl: './bridges.component.html',
  styleUrls: ['./bridges.component.scss']
})
export class BridgesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
