import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-not-fount',
  templateUrl: './not-fount.component.html',
  styleUrls: ['./not-fount.component.scss']
})
export class NotFountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
