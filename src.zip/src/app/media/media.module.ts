import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MediaComponent } from './media/media.component';
import { RouterModule } from '@angular/router';
const router = [
  {path: '', component: MediaComponent},
];
@NgModule({
  declarations: [MediaComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(router),
  ]
})
export class MediaModule { }
