import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './homeandextra/home/home.component';
import { NotFountComponent } from './homeandextra/not-fount/not-fount.component';

const routes: Routes = [
  {path: 'home', component: HomeComponent},
  {path: '', redirectTo: '/home', pathMatch: 'full'},
  {path: 'about', loadChildren: 'src/app/about/about.module#AboutModule'},
  {path: 'business', loadChildren: 'src/app/business/business.module#BusinessModule'},
  {path: 'projects', loadChildren: 'src/app/projects/projects.module#ProjectsModule'},
  {path: 'media', loadChildren: 'src/app/media/media.module#MediaModule'},
  {path: 'contactus', loadChildren: 'src/app/contactus/contactus.module#ContactusModule'},
  {path: 'carrier', loadChildren: 'src/app/carrier/carrier.module#CarrierModule'},
  {path: 'machinery', loadChildren: 'src/app/machinery/machinery.module#MachineryModule'},
  {path: '**', component: NotFountComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
