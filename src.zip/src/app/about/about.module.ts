import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BoardDirectorsComponent } from './board-directors/board-directors.component';
import { RegistraionsComponent } from './registraions/registraions.component';
import { MissionComponent } from './mission/mission.component';
import { RouterModule } from '@angular/router';
import { CompanyOverviewComponent } from './company-overview/company-overview.component';
const router = [
  {path: 'overview', component: CompanyOverviewComponent},
  {path: 'boardDirectors', component: BoardDirectorsComponent},
  {path: 'visionAndMission', component: RegistraionsComponent},
  {path: 'registration', component: MissionComponent}
];
@NgModule({
  declarations: [CompanyOverviewComponent, BoardDirectorsComponent, RegistraionsComponent, MissionComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(router),
  ]
})
export class AboutModule { }
