import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistraionsComponent } from './registraions.component';

describe('RegistraionsComponent', () => {
  let component: RegistraionsComponent;
  let fixture: ComponentFixture<RegistraionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistraionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistraionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
