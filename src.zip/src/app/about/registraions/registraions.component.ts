import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registraions',
  templateUrl: './registraions.component.html',
  styleUrls: ['./registraions.component.scss']
})
export class RegistraionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
