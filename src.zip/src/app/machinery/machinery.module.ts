import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CrushersComponent } from './crushers/crushers.component';
import { EarthEquipmentComponent } from './earth-equipment/earth-equipment.component';
import { MiningEquipmentComponent } from './mining-equipment/mining-equipment.component';
import { ConcreteWorkEquipmentsComponent } from './concrete-work-equipments/concrete-work-equipments.component';
import { TransportationEquipmentsComponent } from './transportation-equipments/transportation-equipments.component';
import { RigidPavementEquipmentComponent } from './rigid-pavement-equipment/rigid-pavement-equipment.component';
import { FlexiblePavementEquipmentComponent } from './flexible-pavement-equipment/flexible-pavement-equipment.component';
import { RouterModule } from '@angular/router';
const router = [
  {path: 'crushers', component: CrushersComponent},
  {path: 'earthEquipments', component: EarthEquipmentComponent},
  {path: 'miningEquipment', component: MiningEquipmentComponent},
  {path: 'concreteWorkEquipments', component: ConcreteWorkEquipmentsComponent},
  {path: 'transportationEquipments', component: TransportationEquipmentsComponent},
  {path: 'rigidPavementEquipment', component: RigidPavementEquipmentComponent},
  {path: 'flexiblePavementEquipment', component: FlexiblePavementEquipmentComponent},
];
@NgModule({
  declarations: [CrushersComponent, EarthEquipmentComponent, MiningEquipmentComponent,
    ConcreteWorkEquipmentsComponent, TransportationEquipmentsComponent,
    RigidPavementEquipmentComponent, FlexiblePavementEquipmentComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(router),
  ]
})
export class MachineryModule { }
