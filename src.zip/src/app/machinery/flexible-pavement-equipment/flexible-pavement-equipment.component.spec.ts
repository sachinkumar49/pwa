import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FlexiblePavementEquipmentComponent } from './flexible-pavement-equipment.component';

describe('FlexiblePavementEquipmentComponent', () => {
  let component: FlexiblePavementEquipmentComponent;
  let fixture: ComponentFixture<FlexiblePavementEquipmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlexiblePavementEquipmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FlexiblePavementEquipmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
