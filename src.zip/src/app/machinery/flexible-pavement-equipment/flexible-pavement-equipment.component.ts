import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flexible-pavement-equipment',
  templateUrl: './flexible-pavement-equipment.component.html',
  styleUrls: ['./flexible-pavement-equipment.component.scss']
})
export class FlexiblePavementEquipmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
