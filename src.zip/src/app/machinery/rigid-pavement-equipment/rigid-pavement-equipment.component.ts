import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rigid-pavement-equipment',
  templateUrl: './rigid-pavement-equipment.component.html',
  styleUrls: ['./rigid-pavement-equipment.component.scss']
})
export class RigidPavementEquipmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
