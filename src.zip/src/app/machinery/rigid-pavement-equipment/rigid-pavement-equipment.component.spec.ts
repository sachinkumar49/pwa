import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RigidPavementEquipmentComponent } from './rigid-pavement-equipment.component';

describe('RigidPavementEquipmentComponent', () => {
  let component: RigidPavementEquipmentComponent;
  let fixture: ComponentFixture<RigidPavementEquipmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RigidPavementEquipmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RigidPavementEquipmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
