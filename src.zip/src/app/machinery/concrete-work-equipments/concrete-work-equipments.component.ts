import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-concrete-work-equipments',
  templateUrl: './concrete-work-equipments.component.html',
  styleUrls: ['./concrete-work-equipments.component.scss']
})
export class ConcreteWorkEquipmentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
