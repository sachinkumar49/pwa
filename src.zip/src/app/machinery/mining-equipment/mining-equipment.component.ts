import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mining-equipment',
  templateUrl: './mining-equipment.component.html',
  styleUrls: ['./mining-equipment.component.scss']
})
export class MiningEquipmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
