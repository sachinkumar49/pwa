import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransportationEquipmentsComponent } from './transportation-equipments.component';

describe('TransportationEquipmentsComponent', () => {
  let component: TransportationEquipmentsComponent;
  let fixture: ComponentFixture<TransportationEquipmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransportationEquipmentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransportationEquipmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
