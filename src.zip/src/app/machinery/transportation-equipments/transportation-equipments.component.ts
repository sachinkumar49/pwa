import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transportation-equipments',
  templateUrl: './transportation-equipments.component.html',
  styleUrls: ['./transportation-equipments.component.scss']
})
export class TransportationEquipmentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
