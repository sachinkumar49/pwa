import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EarthEquipmentComponent } from './earth-equipment.component';

describe('EarthEquipmentComponent', () => {
  let component: EarthEquipmentComponent;
  let fixture: ComponentFixture<EarthEquipmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EarthEquipmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EarthEquipmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
