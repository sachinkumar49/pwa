import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-earth-equipment',
  templateUrl: './earth-equipment.component.html',
  styleUrls: ['./earth-equipment.component.scss']
})
export class EarthEquipmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
