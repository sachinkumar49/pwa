import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crushers',
  templateUrl: './crushers.component.html',
  styleUrls: ['./crushers.component.scss']
})
export class CrushersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
