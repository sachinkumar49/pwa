import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CrushersComponent } from './crushers.component';

describe('CrushersComponent', () => {
  let component: CrushersComponent;
  let fixture: ComponentFixture<CrushersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CrushersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CrushersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
